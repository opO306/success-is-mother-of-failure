# 통합 검토의 추가 실행 증거

`reproduce_dag_checks.py`를 실행하면 `dag_recheck_results.json`과 같은 종류의 결과를 얻는다. 표준 Python 및 mpmath가 필요하다. 이번 실행은 Python 3.13.5, mpmath 1.3.0이었다.

```sh
python reproduce_dag_checks.py
```

## 범위

- `source/exact_expression_gate_v0/dag.py`는 GitHub 연결에서 조회한 고정 commit 9dfd3f853c74426d0c984ac91c45f40955da45b7의 바이트 일치 사본이다.
- Git blob SHA-1: 8e6fe1e360b99a3f9dd6dda23822b38622e7a3bd.
- 원본 DAG 클래스와 build_kdk 함수를 실행하되 Lang 힘 의존성은 호출 시 실패하는 시험 대역으로 차단했다.
- 실제 Lang 힘 호출 0건. 전체 repository/pytest/campaign/checker 실행 또는 연속 물리 감사가 아니다.
- 거리 0 시험의 양수 r_min=1은 명시적인 시험 대역이며 물리 모델 상수라는 주장이 아니다.
- halfway 반례는 별도 무힘 운동 입력이다. 64~8192의 명시된 정밀도 목록에서 A는 미결정, B는 64에서 확정했다.
- 메모리 검사는 새로운 한 입자 자유비행 입력의 노드 수 검사다. 봉인 F_free의 숫자나 RAM bytes 측정으로 해석하지 않는다.
- `attachment_integrity_checks.json`은 제출 ZIP의 자체 manifest 22건 및 제출 에너지 JSON의 내부 산술 일관성을 검사한 기록이다. 에너지 생성 공식을 독립 재계산하지 않았다.

검사 결과의 성공은 알려진 결함 및 구조 특성을 재현했다는 뜻이지, 생산 구현이 수학적 정확성 인증을 통과했다는 뜻이 아니다.
