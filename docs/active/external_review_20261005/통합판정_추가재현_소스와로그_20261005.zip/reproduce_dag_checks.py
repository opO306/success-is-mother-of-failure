"""Limited read-only recheck of the attached audit's DAG findings.

Original dag.py must match the pinned Git blob. No campaign/checker or Lang force
implementation is imported. The positive r_min=1 stub is only for the R=0
rejection test, not a substitute physical parameter. This is not a physics audit.
"""
from __future__ import annotations
import hashlib
import importlib.util
import json
import platform
import sys
import types
from fractions import Fraction as Q
from pathlib import Path
import mpmath
from mpmath import iv

ROOT = Path(__file__).resolve().parent
SRC = ROOT/'source'/'exact_expression_gate_v0'/'dag.py'
data = SRC.read_bytes()
blob = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
assert blob == '8e6fe1e360b99a3f9dd6dda23822b38622e7a3bd'
pkg = types.ModuleType('exact_expression_gate_v0'); pkg.__path__ = [str(SRC.parent)]
sys.modules[pkg.__name__] = pkg
li = types.ModuleType('exact_expression_gate_v0.lang_iv')
li.L = types.SimpleNamespace(R_MIN_BOHR=Q(1))
def exact_constant(x):
    q=Q(x)
    return iv.mpf(q.numerator)/iv.mpf(q.denominator)
li.c = exact_constant
force_calls=0
def prohibited_force(_):
    global force_calls
    force_calls += 1
    raise AssertionError('No physical force evaluations are permitted in this check.')
li.G_of_R2 = prohibited_force
sys.modules[li.__name__] = li
spec = importlib.util.spec_from_file_location('exact_expression_gate_v0.dag',SRC)
assert spec and spec.loader
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

def rational_endpoint(t):
    sign, mantissa, exponent, bitcount = t
    if bitcount < 0:
        raise ValueError('Nonfinite endpoint')
    q=Q(-mantissa if sign else mantissa)
    return q*(1<<exponent) if exponent>=0 else q/Q(1<<(-exponent))

def round_even(q, fractional_bits):
    q *= 1<<fractional_bits
    n,r=divmod(q.numerator,q.denominator)
    return n+int(2*r>q.denominator or (2*r==q.denominator and n%2!=0))

def cells(values, position_count):
    out=[]
    for i,v in enumerate(values):
        lo,hi=map(rational_endpoint,v._mpi_)
        assert lo<=hi
        f=48 if i<position_count else 80
        a,b=round_even(lo,f),round_even(hi,f)
        if a!=b:return None
        out.append(a)
    return out

mass=Q(399623831237000000,5485799090441)
dt=Q(40); z=(Q(0),)*3
report={
 'scope':'Original byte-matched DAG only; independent harness; no campaign, checker, or Lang force execution.',
 'snapshot':'9dfd3f853c74426d0c984ac91c45f40955da45b7',
 'git_blob_sha1':blob,
 'environment':{'python':platform.python_version(),'mpmath':mpmath.__version__},
 'tests':{}}

out={}
for opt in (False,True):
    d=mod.DAG(opt); qi,pi=mod.build_kdk(d,[z,z],[z,z],mass,dt,1,{1})[1]
    name='B' if opt else 'A'
    try:
        v=d.evaluate(qi+pi,128)
        out[name]={'status':'RETURNED','cells':cells(v,len(qi))}
    except ValueError as exc:
        out[name]={'status':'REFUSED_DOMAIN','message':str(exc)}
assert out['A']['status']=='REFUSED_DOMAIN' and out['B']['cells']==[0]*12
report['tests']['DOMAIN_ERASURE']={'scope':'Out-of-domain coincident particles; not a sealed trajectory.','outcomes':out}

q0=[(Q(1,1<<49)-dt/mass,Q(0),Q(0))]; p0=[(Q(1),Q(0),Q(0))]
assert q0[0][0]+dt*p0[0][0]/mass == Q(1,1<<49)
assert round_even(Q(1,1<<49),48)==0
grid=[64,96,128,192,256,384,512,768,1024,1536,2048,3072,4096,6144,8192]
out={}
for opt in (False,True):
    d=mod.DAG(opt); qi,pi=mod.build_kdk(d,q0,p0,mass,dt,1,{1})[1]
    row={'first_decided_bits':None,'attempts':[]}
    for b in grid:
        result=cells(d.evaluate(qi+pi,b),len(qi))
        row['attempts'].append({'bits':b,'decided':result is not None})
        if result is not None:
            row['first_decided_bits']=b; row['cells']=result; break
    out['B' if opt else 'A']=row
assert out['A']['first_decided_bits'] is None
assert out['B']['first_decided_bits']==64 and out['B']['cells'][0]==0
report['tests']['REPRESENTATION_SENSITIVE_PRECISION']={
 'scope':'Synthetic one-particle force-free exact halfway case; campaign skipping not executed here.',
 'q0_x':str(q0[0][0]),'p0_x':'1','q1_x_exact':str(Q(1,1<<49)),
 'grid':grid,'outcomes':out}

rows=[]
for t in (10,100,1000,10000):
    d=mod.DAG(True)
    qi,pi=mod.build_kdk(d,[z],[(Q(1),Q(2),Q(3))],mass,dt,t,{t})[t]
    expected=[t*dt*Q(k)/mass for k in (1,2,3)] + [Q(k) for k in (1,2,3)]
    assert all(d.nodes[r]==('c',x) for r,x in zip(qi+pi,expected))
    rows.append({'steps':t,'reachable_nodes':d.reachable(qi+pi)[0],
                 'retained_nodes':len(d.nodes),'index_entries':len(d.index)})
assert all(row['reachable_nodes']==6 for row in rows)
assert all(a['retained_nodes']<b['retained_nodes'] for a,b in zip(rows,rows[1:]))
report['tests']['RETAINED_HISTORY']={'scope':'New force-free initial condition, not sealed F_free; counts not byte/RSS benchmarks.','rows':rows}
assert force_calls==0
report['force_evaluator_calls']=force_calls
(ROOT/'dag_recheck_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
