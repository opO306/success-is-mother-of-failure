"""Structural tree-counter stress test. No interval force evaluations are performed."""
from __future__ import annotations
import hashlib, importlib, json, sys, time, types
from pathlib import Path
from fractions import Fraction as Q
from mpmath import iv
ROOT=Path(__file__).resolve().parent
import argparse
_parser=argparse.ArgumentParser(description=__doc__)
_parser.add_argument('--repo',type=Path,help='Read-only path to the target repository at an audited commit')
_parser.add_argument('--out',type=Path,help='Evidence output directory')
_args=_parser.parse_args()
OUT=_args.out.resolve() if _args.out else ROOT/'evidence'
OUT.mkdir(parents=True,exist_ok=True)
SOURCE=_args.repo.resolve() if _args.repo else ROOT/'source'
if not SOURCE.is_dir():
    _parser.error('Supply --repo PATH_TO_TARGET_REPOSITORY')
(ROOT/'evidence').mkdir(exist_ok=True)
observed={}
for fn,shas in [('dag.py',('8e6fe1e360b99a3f9dd6dda23822b38622e7a3bd',)),('campaign.py',('274788638ea01056e3a1c189ba9653497e092b3b','04fac0a813c3771d34bd8179f268421914e71b5e'))]:
    b=(SOURCE/'exact_expression_gate_v0'/fn).read_bytes()
    actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
    assert actual in shas
    observed[fn]=actual
li=types.ModuleType('exact_expression_gate_v0.lang_iv')
li.L=types.SimpleNamespace(R_MIN_BOHR=Q(1))
def c(x):
    x=Q(x); return iv.mpf(x.numerator)/iv.mpf(x.denominator)
li.c=c
li.G_of_R2=lambda _: (_ for _ in ()).throw(AssertionError('No force evaluations allowed'))
sys.modules[li.__name__]=li
ar=types.ModuleType('a_reference'); ar.__path__=[]
cr=types.ModuleType('a_reference.c1b1_two_atom')
cr.AR40_MASS_ME=Q('39.9623831237')/Q('5.485799090441e-4')
ar.c1b1_two_atom=cr
sys.modules['a_reference']=ar; sys.modules[cr.__name__]=cr
sys.path.insert(0,str(SOURCE))
cam=importlib.import_module('exact_expression_gate_v0.campaign')
DAG=cam.DAG; build=cam.build_kdk
res=[]
for steps in (100,1000,3000):
    d=DAG(False); q,p=cam.SCENARIOS['A2_bound']
    t0=time.perf_counter()
    snaps=build(d,q,p,cam.MASS,cam.DT,steps,{steps})
    build_s=time.perf_counter()-t0
    roots=sum((snaps[steps][0],snaps[steps][1]),[])
    t0=time.perf_counter(); n=cam.tree_size_estimate(d,roots); count_s=time.perf_counter()-t0
    limit=sys.get_int_max_str_digits()
    try:
        serialized=json.dumps({'tree_size':n})
        json_result='SUCCESS'; digits=len(str(n))
    except ValueError as e:
        json_result=str(e)
        # Count digits exactly using powers of ten, without decimal conversion.
        digits=(n.bit_length()*30103)//100000+1
        while n<10**(digits-1): digits-=1
        while n>=10**digits: digits+=1
    stored=n.bit_length() if observed['campaign.py']=='04fac0a813c3771d34bd8179f268421914e71b5e' else n
    try:
        json.dumps({'stored_counter':stored})
        campaign_json_result='SUCCESS'
    except ValueError:
        campaign_json_result='ValueError'
    row={'campaign_json_result':campaign_json_result,'steps':steps,'nodes_created':len(d.nodes),'reachable':d.reachable(roots),
         'tree_count_bits':n.bit_length(),'tree_count_decimal_digits':digits,
         'build_s':build_s,'count_s':count_s,'int_max_str_digits':limit,
         'json_result':json_result}
    res.append(row); print(json.dumps(row),flush=True)
    (OUT/'tree_counter_results.json').write_text(json.dumps(res,indent=2))
    del d,snaps,roots,n
