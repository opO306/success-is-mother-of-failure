"""Targeted adversarial checks of commits 848ceaf5 / 9dfd3f8 (not a full physics audit).

The three source files are byte-identical to the GitHub blobs, checked below.
A deliberately inert force dependency is installed for structural/force-free tests.
No Lang trajectory is evaluated, and no production repository is modified.
"""
from __future__ import annotations
import hashlib
import importlib
import json
import platform
import sys
import time
import tracemalloc
import types
from fractions import Fraction as Q
from pathlib import Path

ROOT = Path(__file__).resolve().parent
import argparse
_parser = argparse.ArgumentParser(description=__doc__)
_parser.add_argument('--repo', type=Path, help='Read-only path to the target repository at an audited commit')
_parser.add_argument('--out', type=Path, help='Evidence output directory')
_args = _parser.parse_args()
OUT = _args.out.resolve() if _args.out else ROOT / 'evidence'
OUT.mkdir(parents=True, exist_ok=True)
SOURCE = _args.repo.resolve() if _args.repo else ROOT / 'source'
if not SOURCE.is_dir():
    _parser.error('Supply --repo PATH_TO_TARGET_REPOSITORY')
EXPECTED_VERSIONS = {
 '848ceaf5b8c170d4719f1317720cfcff367e6904': {
    'dag.py': '8e6fe1e360b99a3f9dd6dda23822b38622e7a3bd',
    'checker.py': 'deea498c280ee8528a4cb522d25a6e6c4f48a6d7',
    'campaign.py': '274788638ea01056e3a1c189ba9653497e092b3b'},
 '9dfd3f853c74426d0c984ac91c45f40955da45b7': {
    'dag.py': '8e6fe1e360b99a3f9dd6dda23822b38622e7a3bd',
    'checker.py': '7dc28d10a10bba9cd5dc9183501f659757e6340d',
    'campaign.py': '04fac0a813c3771d34bd8179f268421914e71b5e'}
}
manifest = []
observed = {}
for name in ('dag.py','checker.py','campaign.py'):
    b = (SOURCE / 'exact_expression_gate_v0' / name).read_bytes()
    actual = hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
    observed[name] = actual
    manifest.append({'file':name, 'bytes':len(b), 'git_blob_sha1':actual,
                     'sha256':hashlib.sha256(b).hexdigest()})
matches = [commit for commit, expected in EXPECTED_VERSIONS.items() if observed == expected]
if len(matches) != 1:
    raise RuntimeError('Sources do not match either audited commit: ' + repr(observed))
selected_commit = matches[0]

import mpmath
from mpmath import iv
mass = Q('39.9623831237') / Q('5.485799090441e-4')
li = types.ModuleType('exact_expression_gate_v0.lang_iv')
# The actual positive r_min value is irrelevant to the zero-distance counterexample.
# This is explicitly a stub threshold, not a claim about the physical model's value.
li.L = types.SimpleNamespace(R_MIN_BOHR=Q(1))
def c(x):
    x = Q(x)
    return iv.mpf(x.numerator) / iv.mpf(x.denominator)
li.c = c
force_calls = 0
def no_force_evaluation(_):
    global force_calls
    force_calls += 1
    raise AssertionError('This targeted suite must never evaluate a Lang force.')
li.G_of_R2 = no_force_evaluation
sys.modules[li.__name__] = li
ar = types.ModuleType('a_reference')
ar.__path__ = []
cr = types.ModuleType('a_reference.c1b1_two_atom')
cr.AR40_MASS_ME = mass
ar.c1b1_two_atom = cr
sys.modules['a_reference'] = ar
sys.modules[cr.__name__] = cr
sys.path.insert(0, str(SOURCE))
dagmod = importlib.import_module('exact_expression_gate_v0.dag')
cam = importlib.import_module('exact_expression_gate_v0.campaign')
chk = importlib.import_module('exact_expression_gate_v0.checker')
DAG, build = dagmod.DAG, dagmod.build_kdk
report = {
 'commit': selected_commit,
 'environment': {'python':platform.python_version(), 'mpmath':mpmath.__version__,
                 'int_max_str_digits':sys.get_int_max_str_digits()},
 'scope': 'Byte-matched target source; inert force stub; no physical Lang trajectories; not LOCAL FULL.',
 'source_manifest':manifest,
 'tests':{}
}
def save():
    (OUT / 'attack_results.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
def done(key, value):
    report['tests'][key] = value
    save()
    print(key, json.dumps(value, ensure_ascii=False), flush=True)

# A report containing zero independently replayed checkpoints is labelled PROMISING.
forged = OUT / 'forged_reports'
forged.mkdir(exist_ok=True)
for name in chk.NAMES:
    b0, b1 = (6, 6) if name == 'F_free' else (10, 20)
    obj = {
      'protocol': {'checkpoints':[10,100,1000], 'precision_grid':[64,96,128,192,256]},
      'result': {
        'name':name, 'checkpoints':[20,200],
        'A': {'reachable':{'20':{'size':100}, '200':{'size':1000}},
              'required_bits':{'20':128, '200':128}},
        'B': {'reachable':{'20':{'size':b0}, '200':{'size':b1}},
              'bytes_per_size_unit':1, 'build_s':1, 'eval':{}},
        'C': {}, 'intrinsic_amplification_log2':{}
      }
    }
    (forged / f'{name}.json').write_text(json.dumps(obj), encoding='utf-8')
verdict = chk.check(forged, fast=False)
assert verdict['verdict'] == 'PROMISING'
assert verdict['replay_confirmations'] == []
done('F_CHECK_EMPTY_CONFIRMATIONS', {
 'verdict':verdict['verdict'], 'independent_replay_confirmations':0,
 'cells_present':False, 'seal_present':False, 'B_evaluations':0, 'C_evaluations':0,
 'note':'Deliberately malformed synthetic reports, not genuine campaign outputs.'})

# Zero-distance pair: optimizer erases the undefined G(0) behind zero products.
z = (Q(0),)*3
outcomes = {}
for opt in (False,True):
    d = DAG(opt)
    snaps = build(d,[z,z],[z,z],mass,Q(40),1,{1})
    qi, pi = snaps[1]
    reachable_G = sum(d.nodes[i][0]=='G' for i in d._collect(qi+pi))
    try:
        vals = d.evaluate(qi+pi,128)
        result = {'status':'DECIDED', 'cells':cam.decide(vals[:len(qi)],vals[len(qi):]),
                  'reachable_G_nodes':reachable_G}
    except ValueError as e:
        result = {'status':'REFUSED', 'error':str(e), 'reachable_G_nodes':reachable_G}
    outcomes['B' if opt else 'A'] = result
assert outcomes['A']['status']=='REFUSED'
assert outcomes['B']['cells']==[0]*12
done('F_DOMAIN_ERASURE', {'input':'two coincident stationary particles; one KDK step',
                         'scope':'Outside the four sealed scenarios; generalized partial-domain contract attack',
                         'outcomes':outcomes})

# Exact halfway rounding: independent algebra evaluation B decides; A does not.
# For one force-free particle q0 = 2^-49 - 40/m, p0 = 1 gives q1 = 2^-49 exactly.
q0 = [(Q(1,1<<49) - Q(40)/mass, Q(0), Q(0))]
p0 = [(Q(1),Q(0),Q(0))]
grid = [64,96,128,192,256,384,512,768,1024,1536,2048,3072,4096,6144,8192]
mid = {}
for opt in (False,True):
    d = DAG(opt)
    snaps = build(d,q0,p0,mass,Q(40),1,{1})
    found, timing = cam.sweep(d,snaps,[1],grid)
    mid['B' if opt else 'A'] = {'decided':bool(found),
                               'bits':found[1][0] if 1 in found else None,
                               'cells':found[1][1] if 1 in found else None}
assert not mid['A']['decided'] and mid['B']['decided']
r = cam.run_scenario('halfway_free_particle',q0,p0,[1],grid,lambda _:None)
assert r['B']['eval']['1']['status']=='skipped (A undecided)'
done('F_A_GATES_B', {'q0x':str(q0[0][0]), 'p0x':'1', 'exact_q1x':'1/562949953421312',
                     'direct_evaluation':mid,
                     'campaign_B_status':r['B']['eval']['1']['status'],
                     'scope':'New exact force-free input, not a sealed initial condition.'})

# Actual retained node count under sealed free flight grows despite six live roots.
free=[]
for t in (10,100,1000,10000):
    tracemalloc.start()
    d=DAG(True)
    q,p=cam.SCENARIOS['F_free']
    start=time.perf_counter()
    snaps=build(d,q,p,mass,Q(40),t,{t})
    qi,pi=snaps[t]
    current,peak=tracemalloc.get_traced_memory()
    tracemalloc.stop()
    live_nodes,live_edges=d.reachable(qi+pi)
    free.append({'steps':t, 'created_nodes':len(d.nodes), 'index_entries':len(d.index),
                 'reachable_nodes':live_nodes, 'reachable_edges':live_edges,
                 'tracemalloc_current_bytes':current, 'tracemalloc_peak_bytes':peak,
                 'build_seconds':time.perf_counter()-start})
    del d,snaps
assert all(a['reachable_nodes']==6 for a in free)
assert free[-1]['created_nodes']>free[-2]['created_nodes']
done('F_RETAINED_HISTORY',free)

# Partial return after a domain failure is indistinguishable from a finished replay state.
out,state=cam.replay([z,z],[z,z],100,400,set())
assert out=={}
assert all(v==0 for a in state for row in a for v in row)
done('F_REPLAY_EARLY_RETURN', {'requested_steps':100, 'completed_steps':0,
                              'checkpoint_set':[], 'returned_checkpoint_map':out,
                              'returned_initial_state':True,
                              'return_has_completion_status':False,
                              'scope':'Invalid initial distance; direct control-flow reproduction.'})

# Counting graph nodes misses arbitrary-precision payload sizes.
d=DAG(True)
x=d.const(2)
for _ in range(20):
    x=d.mul(x,x)
num=d.nodes[x][1].numerator
assert num.bit_length()==(1<<20)+1
done('F_NODE_COUNT_NOT_BITS', {'operation':'20 exact constant squarings starting at 2',
                             'reachable_nodes':d.reachable([x])[0],
                             'numerator_bits':num.bit_length(),
                             'scope':'Allowed expression constructors, not a demonstrated KDK trajectory.'})

# FX word-size boundary is not checked by cell().
iv.prec=128
raw=cam.cell(c(Q(1<<47)),48)
assert raw==(1<<95)
done('F_FX_RANGE_UNCHECKED', {'input_q':str(1<<47), 'returned_raw':str(raw),
                            'signed_FX96_max_raw':str((1<<95)-1),
                            'scope':'Specification ambiguity if "grid" intentionally means an unbounded lattice.'})
# Limited regression of the new per-scenario base-file preservation fix.
if selected_commit.startswith('9dfd3f8'):
    fault_dir = OUT / 'synthetic_extension_failure'
    fault_dir.mkdir(exist_ok=True)
    original_run_scenario = cam.run_scenario
    def controlled_run(name, q, p, checkpoints, grid, log):
        if checkpoints == [10000]:
            raise ValueError('SYNTHETIC_EXTENSION_FAILURE_FOR_REGRESSION')
        return {'A': {'sweep_s': 0}, 'marker': 'BASE_RESULT_BEFORE_EXTENSION'}
    cam.run_scenario = controlled_run
    try:
        cam.scenario_job(('F_free', [10,100,1000], [64,128], False,
                          str(fault_dir), {'test':'fault injection'}, {}))
    finally:
        cam.run_scenario = original_run_scenario
    base_exists = (fault_dir/'F_free.base.json').is_file()
    error_exists = (fault_dir/'F_free.ERROR.txt').is_file()
    assert base_exists and error_exists
    done('NEW_FIX_BASE_PRESERVED', {'base_file_exists':base_exists,
                                  'error_file_exists':error_exists,
                                  'exception_isolated':True,
                                  'scope':'Fault injection into run_scenario; original scenario_job executed.'})
assert force_calls==0
report['force_evaluator_calls']=force_calls
save()
print('TARGETED SUITE COMPLETE', flush=True)
